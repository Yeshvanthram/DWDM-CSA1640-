# CSA16 Quick Reference - All 42 Exercises at a Glance

## Exercise Summary Table

| # | Exercise | Topic | Tool | File | Key Output |
|---|----------|-------|------|------|-----------|
| 1 | Approximate Median (Grouped Data) | Statistics | R | Part 2 | Median = ~32.5 |
| 2 | Mean, Median, Mode, Quartiles | Statistics | R | Part 1 | Mean=30.3, Median=25, Mode=25 |
| 3 | Min-Max & Z-Score Normalization | Preprocessing | R | Part 2 | Normalized values [0,1] |
| 4 | Bin Smoothing (Mean/Median/Boundaries) | Preprocessing | R | Part 1 | 3 bins with smoothed data |
| 5 | Hospital Data: Age & Body Fat | Statistical Analysis | R | Part 1 | Boxplots, Scatter plot, Q-Q plot |
| 6 | Three Normalization Methods | Preprocessing | R | Part 2 | MinMax, ZScore, Decimal Scaling |
| 7 | Vector Operations (Pencils) | Statistics | R | Part 1 | Mean=10.4, Median=9, Mode=9 |
| 8 | Scatter Plot (Mobile Sales) | Visualization | R | Part 1 | XY scatter plot |
| 9 | Equal-Frequency & Width Partitioning | Preprocessing | R | Part 1 | 3 bins + histograms |
| 10 | IQR and Standard Deviation | Statistics | R | Part 1 | IQR=8.05, SD=5.12 |
| 11 | Quartiles (same as Exercise 2) | Statistics | R | Part 1 | Q1, Q3 values |
| 12 | Covariance & Correlation | Statistics | R | Part 2 | Cov matrix, Correlation matrix |
| 13 | Data Smoothing with Histograms | Preprocessing | R | Part 2 | 3 bins, smoothed values |
| 14 | Class Performance (Boxplot Comparison) | Visualization | R | Part 1 | Side-by-side boxplots |
| 15 | Normalization (Same as 3) | Preprocessing | R | Part 2 | Normalized values |
| 16 | AirPassengers Histogram | Visualization | R | Part 1 | Histogram plot |
| 17 | Multiple Lines Chart (mtcars) | Visualization | R | Part 1 | 2-line plot |
| 18 | Linear Regression (Water Dataset) | Regression | R | Part 1 | Model summary + prediction |
| 19 | Boxplot (MPG vs Cylinders) | Visualization | R | Part 1 | Boxplot by group |
| 20 | Outliers Detection | Visualization | R | Part 1 | Boxplot with identified outliers |
| 21 | Blood Pressure vs Age | Visualization | R | Part 1 | Scatter + bar chart |
| 22 | Apriori Algorithm Setup | Association Rules | WEKA/R | Part 3 | Frequent itemsets |
| 23 | Association Rules Math | Association Rules | Manual | Part 3 | Max rules = 186 (example) |
| 24 | Naive Bayes Classification | Classification | WEKA | Part 3 | Confusion matrix + accuracy |
| 25 | Diabetes Regression Analysis | Regression | R | Part 1 | Linear & multiple regression |
| 26 | WEKA Apriori (T1-T5) | Association Rules | WEKA | Part 3 | Strong rules with s,c > thresh |
| 27 | Decision Tree Classifier | Classification | WEKA | Part 3 | Decision tree + rules |
| 28 | ARFF File Format & Rules | Association Rules | WEKA | Part 3 | Association rules (33% sup, 60% conf) |
| 29 | Rule-based vs Decision Tree | Classification | WEKA | Part 3 | Accuracy comparison |
| 30 | Customer Segmentation (K-Means) | Clustering | R/WEKA | Part 3 | 5 customer segments |
| 31 | K-Means CSV Data | Clustering | R/WEKA | Part 1/3 | Cluster assignments |
| 32 | Naive Bayes vs SVM | Classification | WEKA | Part 3 | Classifier comparison |
| 33 | Vegetarian Count | Statistics | R | Part 1 | Count: veg=7, non-veg=3 |
| 34 | Scatter Plot (Mobile Sales) | Visualization | R | Part 1 | Scatter plot |
| 35 | FP-Growth Algorithm | Association Rules | Manual/R | Part 3 | Strong rules |
| 36 | Diabetes: Decision Tree vs SVM | Classification | WEKA | Part 3 | Model comparison (Accuracy %) |
| 37 | Data Partitioning (Equal-Freq/Width) | Preprocessing | R | Part 1/3 | 3 partitioned bins |
| 38 | Decision Tree from Diagram | Classification | WEKA | Part 3 | Generated tree + rules |
| 39 | Apriori vs FP-Growth (TV Brands) | Association Rules | WEKA | Part 3 | Algorithm efficiency comparison |
| 40 | Four Normalization Methods (Sports) | Preprocessing | R | Part 2 | 4 normalized values |
| 41 | Variance & SD (Car Speed/Time) | Statistics | R | Part 2 | Variance & SD for 2 variables |
| 42 | Association Rules with Metarules | Association Rules | Manual/WEKA | Part 3 | Strong rules list |

---

## Quick Selection Guide

### By Topic

#### **Statistics & Descriptive Analysis** (10 exercises)
- Exercise 1: Grouped data median
- Exercise 2: Mean, median, mode, midrange, quartiles
- Exercise 7: Vector statistics (mean, median, mode)
- Exercise 10: IQR and standard deviation
- Exercise 12: Covariance and correlation
- Exercise 33: Category counting
- Exercise 41: Variance and standard deviation

#### **Data Visualization** (9 exercises)
- Exercise 5: Boxplots, scatter plot, Q-Q plot
- Exercise 8: Scatter plot
- Exercise 14: Boxplot comparison
- Exercise 16: Histogram
- Exercise 17: Multiple line chart
- Exercise 19: Grouped boxplot
- Exercise 20: Outliers visualization
- Exercise 21: Multiple chart types
- Exercise 34: Scatter plot

#### **Data Preprocessing & Normalization** (8 exercises)
- Exercise 3: Min-Max & Z-Score normalization
- Exercise 4: Data smoothing (3 methods)
- Exercise 6: Three normalization methods
- Exercise 9: Equal-frequency and width partitioning
- Exercise 13: Smoothing with histograms
- Exercise 15: Normalization (duplicate of 3)
- Exercise 37: Data partitioning
- Exercise 40: Four normalization methods

#### **Regression Analysis** (2 exercises)
- Exercise 18: Linear regression
- Exercise 25: Linear & multiple regression

#### **Association Rule Mining** (7 exercises)
- Exercise 22: Apriori algorithm
- Exercise 23: Association rules calculation
- Exercise 26: WEKA Apriori
- Exercise 28: ARFF format & association rules
- Exercise 35: FP-Growth algorithm
- Exercise 39: Apriori vs FP-Growth
- Exercise 42: Association rules with metarules

#### **Classification** (6 exercises)
- Exercise 24: Naive Bayes
- Exercise 27: Decision Tree
- Exercise 29: Rule-based vs Decision Tree
- Exercise 32: Naive Bayes vs SVM
- Exercise 36: Decision Tree vs SVM
- Exercise 38: Decision Tree from diagram

#### **Clustering** (3 exercises)
- Exercise 30: Customer segmentation (K-Means)
- Exercise 31: K-Means clustering
- (Exercise 37c: Clustering partitioning - bonus)

---

### By Tool Required

#### **R Only** (22 exercises)
- Part 1: 1, 2, 4, 5, 6, 7, 8, 9, 10, 14, 16, 17, 18, 19, 20, 21, 25, 31, 33, 34
- Part 2: 40, 41
- **Time to complete:** ~1-2 hours (entire Part 1 & 2)

#### **WEKA Required** (12 exercises)
- 22, 23, 24, 26, 27, 28, 29, 32, 35, 36, 38, 39, 42
- **Time to complete:** ~3-4 hours (including learning WEKA)

#### **Manual Calculation** (2 exercises)
- Exercise 23: Maximum association rules
- Exercise 35: FP-Growth walkthrough

---

## Data Files Quick Reference

### Built-in R Datasets Used
- `AirPassengers` - Time series data (Exercise 16)
- `mtcars` - Motor cars data (Exercises 17, 19)
- `water` - Water hardness and mortality (Exercise 18)

### Datasets to Create/Use
- Age values dataset (Exercises 2, 11)
- Strike rates (Exercise 40)
- Car speed/time (Exercise 41)
- Hospital data (Exercises 5, 6)
- Customer data (Exercises 30, 31)
- Diabetes data (Exercises 21, 25, 36)
- Market basket data (Exercises 22-28, 35, 39, 42)

---

## Expected Output Examples

### Statistics Exercises
```
Mean: 30.3
Median: 25
Mode: 25
Q1: 20
Q3: 35
IQR: 15
Standard Deviation: 12.94
```

### Normalization Exercises
```
Min-Max [0,1]: 0.0, 0.25, 0.5, 0.75, 1.0
Z-Score: -1.23, -0.82, 0, 0.82, 1.64
Decimal Scaling: 0.002, 0.003, 0.004, 0.006, 0.010
```

### Data Mining Exercises
```
Frequent Itemsets: {K,E}, {K,Y}, {O,N}
Association Rules: A→B (sup=40%, conf=75%)
Accuracy: 87.65%
Precision: 83.67%
Recall: 82.14%
F1-Score: 82.90%
```

---

## Time Estimates by Exercise Group

| Group | Exercises | Tool | Difficulty | Time |
|-------|-----------|------|------------|------|
| Basic Stats | 1,2,7,10,11,12,33,41 | R | Easy | 30-45 min |
| Visualization | 5,8,14,16,17,19,20,21,34 | R | Easy | 45-60 min |
| Normalization | 3,4,6,9,13,15,37,40 | R | Easy | 45-60 min |
| Regression | 18,25 | R | Medium | 30-45 min |
| Association Rules | 22,23,26,28,35,39,42 | WEKA | Medium | 90-120 min |
| Classification | 24,27,29,32,36,38 | WEKA | Medium-Hard | 90-120 min |
| Clustering | 30,31 | WEKA | Medium | 45-60 min |

**Total Estimated Time:** 20-25 hours (includes learning tools, practice, and experimentation)

---

## Common Calculations Reference

### Exercise 2 Data Analysis
```
Data: 13, 15, 16, 16, 19, 20, 20, 21, 22, 22, 25, 25, 25, 25, 30, 33, 33, 35, 35, 35, 35, 36, 40, 45, 46, 52, 70
Mean: 30.30
Median: 25 (middle values)
Mode: 25 (appears 4 times)
Q1: 20
Q3: 35.25
Midrange: 41.5
```

### Exercise 3 Normalization
```
Original: 200, 300, 400, 600, 1000
Min: 200, Max: 1000, Range: 800

Min-Max: 0.000, 0.125, 0.250, 0.500, 1.000
Z-Score: -0.894, -0.447, 0.000, 0.894, 1.789
```

### Exercise 5 Hospital Data
```
Age: Mean=45.28, SD=13.22, Median=54
Body Fat: Mean=30.11, SD=8.35, Median=31.30
```

---

## Troubleshooting Quick Guide

| Issue | Cause | Solution |
|-------|-------|----------|
| R script won't run | Syntax error or missing data | Check for typos, define data first |
| Plot doesn't show | Graphics device not active | Use windows(), quartz(), or X11() |
| WEKA won't load ARFF | Invalid format | Check @relation, @attribute, @data syntax |
| Apriori returns no rules | Min support too high | Lower threshold or check data |
| Classifier shows 0% accuracy | Data/class mismatch | Verify class column and format |
| Script runs slow | Too much computation | Use subset of data or increase intervals |

---

## Recommended Learning Path

### Day 1-2: Foundation (Exercises 1-10)
- Learn basic statistics: mean, median, mode
- Understand data distributions
- Practice data summarization

### Day 3-4: Visualization (Exercises 5, 8, 14, 16-21)
- Create basic plots
- Understand relationships between variables
- Learn outlier detection

### Day 5: Normalization (Exercises 3-4, 6, 9, 40)
- Master three normalization methods
- Understand data scaling
- Practice equal-frequency partitioning

### Day 6: Regression (Exercises 18, 25)
- Linear regression basics
- Multiple regression
- Prediction and inference

### Day 7-8: Association Rules (Exercises 22-23, 26, 28, 35, 39)
- Learn Apriori algorithm
- Build and evaluate FP-Growth trees
- Generate and interpret rules

### Day 9-10: Classification (Exercises 24, 27, 29, 32, 36)
- Decision trees
- Naive Bayes classifier
- Model comparison and evaluation

### Day 11: Clustering (Exercises 30-31)
- K-Means algorithm
- Customer segmentation
- Cluster interpretation

### Day 12: Review & Integration
- Complete all exercises
- Compare different approaches
- Build comprehensive example

---

## Key Formulas Cheat Sheet

```
STATISTICS:
Mean = Σx / n
Variance = Σ(x - mean)² / (n-1)
SD = √Variance
Covariance = Σ(x - x_mean)(y - y_mean) / (n-1)
Correlation = Covariance / (SD_x × SD_y)

NORMALIZATION:
Min-Max = (v - min) / (max - min)
Z-Score = (v - mean) / SD
Decimal Scaling = v / 10^j

DATA MINING:
Support(X→Y) = Count(X∪Y) / Total
Confidence(X→Y) = Count(X∪Y) / Count(X)
Lift(X→Y) = Confidence(X→Y) / Support(Y)

CLASSIFICATION METRICS:
Accuracy = (TP + TN) / (TP + TN + FP + FN)
Precision = TP / (TP + FP)
Recall = TP / (TP + FN)
F1 = 2 × (Precision × Recall) / (Precision + Recall)
```

---

**Quick Start:** Run `solutions_part1_statistics_and_visualization.R` immediately to see example outputs!

**For Questions:** Refer to the comprehensive README guide included in the package.
